/** 
 * Prints "War Eagle" three times.
 */
public class FirstProgramWithComments 
{

   /**
    * Prints the line "War Eagle!" three times 
    * to standard output, adding one more '!' with
    * each line printed. 
    *
    * @param args Command line arguments (not used).
    */
   public static void main(String[] args)
   {
      System.out.println("War Eagle!"); 
      System.out.println("War Eagle!!"); 
      System.out.println("War Eagle!!!"); 
   }
}