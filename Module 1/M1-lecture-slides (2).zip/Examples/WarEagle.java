/**
   WarEagle - my first program.
 */  
public class WarEagle {

   /**
      Prints War Eagle 3 times.
      @param args - not used.
    */
   public static void main(String[] args) {
   
      System.out.println("War Eagle!");
      System.out.println("War Eagle!!");
      System.out.println("War Eagle!!!");
   
   }
}